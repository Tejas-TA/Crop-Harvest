# Machine Learning Prediction of Crop Harvest
Repository contains the code to predict whether a crop would be alive, damaged due to pesticides or damaged by other means using Machine Learning and Deep Learning
